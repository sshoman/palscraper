@echo off
:: This batch file runs ms.py as an administrator.

:: Check if the script is already running as admin
net session >nul 2>&1
if %errorLevel% == 0 (
    echo Running with administrator privileges.
    echo.
    cd /d "%~dp0"
    python ms.py
    echo.
    echo Script finished.
    pause
) else (
    echo Requesting administrator privileges...
    powershell -Command "Start-Process '%0' -Verb RunAs"
)