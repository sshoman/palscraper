#!/usr/bin/env python3
"""
maps_scraper_chrome_ubuntu.py

Stealth mode added, much slower scrape.
Merges the new features (randomization, runtime query, robust scrolling)
with a Chrome driver setup optimized for Ubuntu.
This version uses a much slower, more "stealthy" configuration to avoid CAPTCHAs.
"""

import os
import re
import csv
import time
import random
import sys
import pickle
from datetime import datetime, timezone
from typing import List, Dict, Tuple, Optional
from urllib.parse import urlparse, urljoin, quote
import importlib.util
from collections import defaultdict

import requests
from bs4 import BeautifulSoup

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import (
    TimeoutException,
    NoSuchElementException,
    StaleElementReferenceException,
    ElementClickInterceptedException,
    WebDriverException
)
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Chrome webdriver imports
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager


# -------------------- DEPENDENCY CHECK --------------------
def check_dependencies():
    """Check if all required libraries are installed and provide installation command if not."""
    required_libs = {
        'requests': 'requests',
        'bs4': 'beautifulsoup4',
        'selenium': 'selenium',
        'webdriver_manager': 'webdriver-manager',
        'lxml': 'lxml'
    }
    missing_libs = []
    for import_name, pip_name in required_libs.items():
        if importlib.util.find_spec(import_name) is None:
            missing_libs.append(pip_name)
    if missing_libs:
        print("[ERROR] Missing required libraries. Please install them using pip:")
        print(f"pip install {' '.join(missing_libs)}")
        return False
    return True

# -------------------- PERFORMANCE MONITOR --------------------
class PerformanceMonitor:
    """Monitor scraping performance and collect metrics"""
    def __init__(self):
        self.metrics = defaultdict(list)
        self.start_time = time.time()
        self.counters = defaultdict(int)

    def record_timing(self, event, duration):
        self.metrics[event].append(duration)

    def record_count(self, event, count):
        self.counters[event] += count

    def increment(self, event):
        self.counters[event] += 1

    def get_stats(self):
        runtime = time.time() - self.start_time
        return {
            'total_runtime': runtime,
            'metrics': dict(self.metrics),
            'counters': dict(self.counters),
            'rate': self.counters.get('items_collected', 0) / runtime if runtime > 0 else 0
        }

    def print_summary(self):
        stats = self.get_stats()
        print(f"\n[PERFORMANCE] Total runtime: {stats['total_runtime']:.2f}s")
        print(f"[PERFORMANCE] Items collected: {stats['counters'].get('items_collected', 0)}")
        print(f"[PERFORMANCE] Collection rate: {stats['rate']:.2f} items/second")
        if stats['metrics'].get('link_collection'):
            avg_time = sum(stats['metrics']['link_collection']) / len(stats['metrics']['link_collection'])
            print(f"[PERFORMANCE] Average link collection time: {avg_time:.2f}s")

# -------------------- SESSION MANAGEMENT --------------------
def save_session_data(driver, filename):
    """Save cookies and local storage for session persistence"""
    try:
        session_data = {
            'cookies': driver.get_cookies(),
            'local_storage': driver.execute_script("return Object.assign({}, localStorage)"),
            'session_storage': driver.execute_script("return Object.assign({}, sessionStorage)"),
            'timestamp': datetime.now(timezone.utc).isoformat()
        }
        with open(filename, 'wb') as f:
            pickle.dump(session_data, f)
        print(f"[INFO] Session data saved to {filename}")
        return True
    except Exception as e:
        print(f"[WARN] Failed to save session data: {e}")
        return False

def load_session_data(driver, filename):
    """Load saved session data"""
    try:
        with open(filename, 'rb') as f:
            session_data = pickle.load(f)

        # Restore cookies
        for cookie in session_data['cookies']:
            try:
                driver.add_cookie(cookie)
            except Exception:
                pass

        # Restore local storage
        if session_data.get('local_storage'):
            for key, value in session_data['local_storage'].items():
                try:
                    driver.execute_script(f"localStorage.setItem('{key}', '{value}')")
                except Exception:
                    pass

        # Restore session storage
        if session_data.get('session_storage'):
            for key, value in session_data['session_storage'].items():
                try:
                    driver.execute_script(f"sessionStorage.setItem('{key}', '{value}')")
                except Exception:
                    pass

        print(f"[INFO] Session data loaded from {filename}")
        return True
    except FileNotFoundError:
        print(f"[INFO] No existing session data found at {filename}")
        return False
    except Exception as e:
        print(f"[WARN] Failed to load session data: {e}")
        return False

# -------------------- RANDOMIZED CONFIG (ENHANCED STEALTH MODE) --------------------
def randomize_config(seed: Optional[int] = None) -> Dict:
    if seed is not None:
        random.seed(seed)
    cfg = {
        # scroll behavior - optimized for better collection
        "MAX_SCROLLS": random.randint(60, 80),  # Increased for better collection
        "SCROLL_CHUNK": random.choice([500, 600, 700]),  # Larger chunks for better content loading
        "SCROLL_PAUSE_MIN": round(random.uniform(1.0, 1.5), 2),  # Slightly longer for content loading
        "SCROLL_PAUSE_MAX": round(random.uniform(2.0, 3.0), 2),  # Slightly longer for content loading
        "NO_NEW_BREAK_CYCLES": random.randint(5, 8),  # More patience for content loading

        # visiting behavior - optimized for efficiency
        "MAX_VISIT_PAGES": random.randint(60, 80),  # Increased capacity
        "MAX_PLACES_LIMIT": 0,
        "CLICK_SLEEP_MIN": round(random.uniform(1.5, 2.5), 2),  # Much faster
        "CLICK_SLEEP_MAX": round(random.uniform(3.0, 5.0), 2),  # Much faster
        "INTER_ITEM_SLEEP_MIN": round(random.uniform(2.0, 4.0), 2),  # Much faster
        "INTER_ITEM_SLEEP_MAX": round(random.uniform(6.0, 10.0), 2),  # Much faster

        # networking & parsing
        "REQUESTS_TIMEOUT": random.randint(8, 12),
        # Updated User-Agents with more variety
        "USER_AGENT": random.choice([
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:121.0) Gecko/20100101 Firefox/121.0",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        ]),
        "CSV_ENCODING": "utf-8",

        # webdriver behavior
        "HEADLESS": False,
        "VERBOSE": True,

        # anti-blocking
        "MAX_CONSECUTIVE_BLOCKS": 2,

        # New features for enhanced efficiency
        "SAVE_COOKIES": True,
        "COOKIE_FILE": "maps_session.pkl",
        "MAX_RETRIES": 3,
        "RETRY_DELAY_BASE": 30,
        "ADAPTIVE_TIMING": True,
        "USE_HUMAN_ACTIONS": True,
        "VIEWPORT_ROTATION": True,
        "SMART_SCROLLING": True,
        "FORCE_SCROLLING": True,  # Force scrolling even if no new links detected initially
        "MIN_RESULTS_BEFORE_STOP": 15,  # Minimum results before considering stopping
        "PERFORMANCE_MODE": "balanced"  # balanced, speed, stealth
    }
    return cfg

CFG = randomize_config()

# -------------------- GLOBALS & PATTERNS --------------------
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}", re.I)
PHONE_RE = re.compile(r'(\+?\d[\d\-\.\s\(\)]{7,}\d)')

# -------------------- UTILITIES --------------------
def sanitize_filename(query: str) -> str:
    base = re.sub(r'[^A-Za-z0-9_\- ]+', '', query).strip().replace(' ', '_')
    if not base:
        base = "maps_results"
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    return f"{base}_{ts}.csv"

def safe_text(elem):
    return elem.get_text(separator=' ', strip=True) if elem else ''

def clean_text(text):
    """Remove emojis, special characters, and extra whitespace from text"""
    if not text:
        return ''
    text = text.replace('"', '').replace('"', '').replace('"', '').replace(''', '').replace(''', '')
    cleaned_chars = []
    for char in text:
        if (ord(char) < 127 and char.isprintable()) or char.isspace() or ord(char) in range(128, 256):
            if char not in ['📍', '📞', '🌐', '⭐', '💰', '🕒']:
                cleaned_chars.append(char)
    text = ''.join(cleaned_chars)
    text = re.sub(r'[^\w\s\+\-\(\)\.,:/#&@]', '', text, flags=re.UNICODE)
    text = ' '.join(text.split())
    return text

def is_probable_email(e: str) -> bool:
    if not e or '@' not in e:
        return False
    e = e.lower()
    if re.search(r'no-?reply|noreply|donotreply|facebook|linkedin|googlemail|example|amazonaws', e):
        return False
    return EMAIL_RE.match(e) is not None

def fetch_emails_from_website(url: str, cfg=CFG) -> List[str]:
    """Fetch the given URL and return a deduped list of plausible emails (mailto prioritized)."""
    if not url:
        return []
    if url.startswith("//"):
        url = "http:" + url
    if not url.startswith("http"):
        url = "http://" + url
    headers = {"User-Agent": cfg["USER_AGENT"]}
    try:
        r = requests.get(url, timeout=cfg["REQUESTS_TIMEOUT"], headers=headers, allow_redirects=True)
        if r.status_code != 200 or not r.text:
            return []
        text = r.text
        mailtos = re.findall(r'href=[\'"]mailto:([^\'"\?<>]+)', text, flags=re.I)
        if mailtos:
            cleaned = [m.split("?")[0].strip() for m in mailtos if is_probable_email(m)]
            if cleaned:
                return list(dict.fromkeys(cleaned))
        found = EMAIL_RE.findall(text)
        found = [f for f in found if is_probable_email(f)]
        return list(dict.fromkeys(found))
    except Exception:
        return []

# -------------------- HUMAN-LIKE INTERACTIONS --------------------
def random_mouse_movement(driver):
    """Add random mouse movements to appear more human"""
    if not random.choice([True, False, True]):  # 2/3 chance to move mouse
        return

    try:
        actions = ActionChains(driver)
        screen_width = driver.execute_script("return window.screen.width")
        screen_height = driver.execute_script("return window.screen.height")

        # Generate random movements
        num_movements = random.randint(1, 3)
        for _ in range(num_movements):
            x = random.randint(50, max(100, screen_width - 50))
            y = random.randint(50, max(100, screen_height - 50))
            actions.move_by_offset(x - screen_width//2, y - screen_height//2)
            actions.pause(random.uniform(0.05, 0.15))

        actions.perform()
        if random.choice([True, False]):  # Sometimes add a small pause
            time.sleep(random.uniform(0.1, 0.3))
    except Exception:
        pass  # Mouse movements are optional, don't fail if they don't work

def human_like_scroll(driver, target_element=None, scroll_direction="down"):
    """Simulate natural human scrolling with variable speeds and patterns"""
    try:
        if target_element and scroll_direction == "down":
            # Scroll to element with natural movement
            actions = ActionChains(driver)
            actions.move_to_element(target_element)

            # Simulate natural scroll with acceleration/deceleration
            scroll_chunks = random.randint(2, 5)
            for i in range(scroll_chunks):
                chunk_size = random.randint(50, 200)
                actions.scroll_by_amount(0, chunk_size)
                # Variable pause between chunks
                pause_time = random.uniform(0.05, 0.2) if i < scroll_chunks - 1 else random.uniform(0.1, 0.4)
                actions.pause(pause_time)

            actions.perform()
        else:
            # Wheel scroll simulation with JavaScript
            scroll_amount = random.randint(200, 500)
            if scroll_direction == "up":
                scroll_amount = -scroll_amount

            driver.execute_script("""
                var scrollAmount = arguments[0];
                var chunks = Math.min(5, Math.floor(Math.abs(scrollAmount) / 100));
                var direction = scrollAmount > 0 ? 1 : -1;
                var chunkSize = Math.abs(scrollAmount) / chunks;

                for(var i = 0; i < chunks; i++) {
                    window.scrollBy(0, chunkSize * direction);
                    // Variable delay between scroll chunks
                    var delay = Math.random() * 150 + 50;
                    await new Promise(resolve => setTimeout(resolve, delay));
                }
            """, scroll_amount)

    except Exception:
        # Fallback to simple scroll if advanced scrolling fails
        try:
            if scroll_direction == "down":
                driver.execute_script("window.scrollBy(0, 300);")
            else:
                driver.execute_script("window.scrollBy(0, -300);")
        except Exception:
            pass

def natural_random_pause(min_multiplier=1.0, max_multiplier=1.0):
    """Generate a natural-feeling pause time"""
    base_pause = random.uniform(0.3, 0.8)
    pause = base_pause * random.uniform(min_multiplier, max_multiplier)
    time.sleep(pause)

# -------------------- ADVANCED CAPTCHA DETECTION --------------------
def advanced_captcha_detection(driver):
    """Enhanced CAPTCHA detection with visual elements and better patterns"""
    try:
        # Check for common CAPTCHA indicators in DOM
        captcha_indicators = [
            "iframe[src*='recaptcha']",
            "div[class*='captcha']",
            "div[id*='captcha']",
            ".g-recaptcha",
            "#captcha",
            "[style*='captcha']",
            "[src*='captcha']",
            ".captcha-container"
        ]

        for indicator in captcha_indicators:
            elements = driver.find_elements(By.CSS_SELECTOR, indicator)
            if elements:
                print(f"[WARN] CAPTCHA element detected: {indicator}")
                return True

        # Check page title and URL for suspicious patterns
        current_title = driver.title.lower()
        current_url = driver.current_url.lower()

        suspicious_patterns = [
            "captcha", "robot", "verify", "unusual", "traffic",
            "blocked", "suspicious", "security", "check"
        ]

        if any(pattern in current_title for pattern in suspicious_patterns):
            print(f"[WARN] CAPTCHA detected in page title: {current_title}")
            return True

        if any(pattern in current_url for pattern in suspicious_patterns):
            print(f"[WARN] CAPTCHA detected in URL: {current_url}")
            return True

        # Check for blocked content patterns in page text
        page_text = driver.page_source.lower()
        blocking_phrases = [
            "our systems have detected unusual traffic",
            "please complete the security check",
            "this page is trying to verify",
            "are you a robot",
            "recaptcha",
            "please verify you are human",
            "access blocked",
            "traffic from your network"
        ]

        for phrase in blocking_phrases:
            if phrase in page_text:
                print(f"[WARN] Blocking phrase detected: {phrase}")
                return True

        # Check for form elements that might indicate verification
        verification_forms = driver.find_elements(By.CSS_SELECTOR, "form[action*='verify'], form[action*='captcha']")
        if verification_forms:
            print("[WARN] Verification form detected")
            return True

        return False

    except Exception as e:
        print(f"[WARN] Error during CAPTCHA detection: {e}")
        return False

def detect_block_or_captcha(page_text: str) -> bool:
    """Legacy function - kept for compatibility"""
    if not page_text:
        return False
    s = page_text.lower()
    checks = [
        "unusual traffic", "detected unusual traffic", "are you a robot",
        "please verify", "sorry", "verify you're not a robot", "recaptcha", "captcha"
    ]
    return any(c in s for c in checks)

def handle_captcha_situation(driver, cfg=CFG):
    """Handle CAPTCHA or blocking situations intelligently"""
    print("[WARN] CAPTCHA/block detected - implementing mitigation strategy")

    # Try refreshing the page first
    if random.choice([True, False]):
        print("[INFO] Attempting page refresh...")
        driver.refresh()
        time.sleep(random.uniform(3, 5))
        return False  # Continue with fresh attempt

    # Implement cool down period
    base_cooldown = cfg.get("RETRY_DELAY_BASE", 30)
    cooldown_multiplier = random.uniform(1.0, 2.0)
    wait_time = int(base_cooldown * cooldown_multiplier)

    print(f"[INFO] Entering cooldown period: {wait_time} seconds")

    # Break cooldown into smaller chunks with periodic checks
    chunk_size = 30  # Check every 30 seconds
    elapsed = 0
    while elapsed < wait_time:
        time.sleep(min(chunk_size, wait_time - elapsed))
        elapsed += chunk_size

        # Periodically check if the block has been lifted
        if elapsed % 60 == 0:  # Every minute
            print(f"[INFO] Checking if block has been lifted... ({elapsed}s elapsed)")
            if not advanced_captcha_detection(driver):
                print("[INFO] Block appears to have been lifted!")
                return True

    print(f"[INFO] Cooldown completed after {wait_time} seconds")
    return False

# -------------------- WEBDRIVER SETUP (Enhanced Chrome Stealth) --------------------
def make_chrome_driver(cfg=CFG):
    """Creates an advanced Chrome driver with comprehensive stealth features."""
    opts = ChromeOptions()

    # Basic configuration
    if cfg["HEADLESS"]:
        opts.add_argument("--headless=new")  # Use new headless mode

    # Viewport randomization for fingerprint variation
    if cfg.get("VIEWPORT_ROTATION", True):
        viewport_sizes = [
            (1920, 1080), (1366, 768), (1440, 900),
            (1536, 864), (1280, 720), (1600, 900)
        ]
        width, height = random.choice(viewport_sizes)
        opts.add_argument(f"--window-size={width},{height}")
    else:
        opts.add_argument("--start-maximized")

    # Essential stability options
    opts.add_argument("--disable-gpu")
    opts.add_argument("--no-sandbox")  # Essential for running as root in Docker/CI
    opts.add_argument("--disable-dev-shm-usage")  # Overcomes limited resource problems

    # Advanced stealth options
    opts.add_argument("--disable-blink-features=AutomationControlled")
    opts.add_experimental_option("excludeSwitches", ["enable-automation"])
    opts.add_experimental_option("useAutomationExtension", False)

    # Additional privacy and anti-detection flags
    opts.add_argument("--disable-web-security")
    opts.add_argument("--disable-features=VizDisplayCompositor")
    opts.add_argument("--ignore-certificate-errors")
    opts.add_argument("--allow-running-insecure-content")
    opts.add_argument("--disable-extensions")
    opts.add_argument("--disable-plugins-discovery")
    opts.add_argument("--disable-background-timer-throttling")
    opts.add_argument("--disable-backgrounding-occluded-windows")
    opts.add_argument("--disable-renderer-backgrounding")

    # Network and loading optimizations
    opts.add_argument("--disable-ipc-flooding-protection")
    opts.add_argument("--disable-background-networking")
    opts.add_argument("--disable-default-apps")
    opts.add_argument("--disable-sync")
    opts.add_argument("--metrics-recording-only")
    opts.add_argument("--no-first-run")
    opts.add_argument("--safebrowsing-disable-auto-update")

    # User agent and language
    opts.add_argument(f"user-agent={cfg['USER_AGENT']}")
    opts.add_argument("--lang=en-US,en")

    # Suppress console noise
    opts.add_argument("--log-level=3")
    opts.add_argument("--silent")

    # Memory optimization
    opts.add_argument("--memory-pressure-off")
    opts.add_argument("--max_old_space_size=4096")

    try:
        service = ChromeService(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service, options=opts)

        # Advanced anti-detection JavaScript injections
        stealth_scripts = [
            # Remove webdriver traces
            "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})",

            # Overwrite plugins array to appear more natural
            "Object.defineProperty(navigator, 'plugins', {get: () => [1, 2, 3, 4, 5]})",

            # Override permissions API
            "Object.defineProperty(navigator, 'permissions', {get: () => ({query: () => Promise.resolve({state: 'granted'})})})",

            # Override WebGL renderer
            "const getParameter = WebGLRenderingContext.prototype.getParameter; WebGLRenderingContext.prototype.getParameter = function(parameter) { if (parameter === 37445) return 'Intel Inc.'; if (parameter === 37446) return 'Intel Iris OpenGL Engine'; return getParameter(parameter) }",

            # Override chrome runtime
            "window.chrome = {runtime: {}}",

            # Override device memory
            "Object.defineProperty(navigator, 'deviceMemory', {get: () => 8})",

            # Override hardware concurrency
            "Object.defineProperty(navigator, 'hardwareConcurrency', {get: () => 4})",

            # Override connection
            "Object.defineProperty(navigator, 'connection', {get: () => ({effectiveType: '4g', rtt: 100, downlink: 10})})",

            # Replace navigator.language
            "Object.defineProperty(navigator, 'language', {get: () => 'en-US'})",
            "Object.defineProperty(navigator, 'languages', {get: () => ['en-US', 'en']})",

            # Override platform
            "Object.defineProperty(navigator, 'platform', {get: () => 'Win32'})"
        ]

        for script in stealth_scripts:
            try:
                driver.execute_script(script)
            except Exception:
                pass  # Some scripts might fail, that's okay

        print("[INFO] Successfully launched enhanced Chrome with stealth features.")
        return driver

    except Exception as e:
        print(f"[ERROR] Failed to start Chrome: {e}")
        return None

# -------------------- EXTRACTION HELPERS --------------------
def extract_details_from_soup(soup: BeautifulSoup) -> Tuple[str, str, str, str, List[str]]:
    name = ''
    address = ''
    website = ''
    phone = ''
    
    name_selectors = [
        'h1[data-attrid="title"]', 'h1.DUwDvf', 'h1.x3AX1-LfntMc-header-title-title', 'h1'
    ]
    for selector in name_selectors:
        elem = soup.select_one(selector)
        if elem and elem.get_text(strip=True) and elem.get_text(strip=True) != 'Results':
            name = clean_text(elem.get_text(strip=True))
            break
    
    address_selectors = [
        'button[data-item-id="address"]', 'button[aria-label*="Address"]', '[data-item-id="address"]'
    ]
    for selector in address_selectors:
        elem = soup.select_one(selector)
        if elem:
            address_text = safe_text(elem)
            if address_text:
                address = clean_text(address_text.replace('Address:', '').strip())
                break

    website_selectors = [
        'a[data-item-id="authority"]', 'a[aria-label*="Website"]', 'a[href*="http"]:not([href*="google.com"])'
    ]
    for selector in website_selectors:
        elem = soup.select_one(selector)
        if elem and elem.get('href'):
            href = elem.get('href')
            if href and not href.startswith('javascript:') and 'google.com' not in href:
                website = href
                break

    phone_selectors = [
        'button[data-item-id*="phone"]', 'button[aria-label*="Phone"]', 'span[aria-label*="Phone"]'
    ]
    for selector in phone_selectors:
        elem = soup.select_one(selector)
        if elem:
            phone_text = safe_text(elem)
            if phone_text:
                phone = clean_text(phone_text.replace('Phone:', '').strip())
                break
    
    if not phone:
        phone_match = re.search(PHONE_RE, soup.get_text())
        if phone_match:
            phone = phone_match.group(1).strip()

    panel_emails = []
    mailto_el = soup.select_one('a[href^="mailto:"]')
    if mailto_el and mailto_el.get('href'):
        candidate = mailto_el.get('href').split(':', 1)[1].split('?')[0]
        if is_probable_email(candidate):
            panel_emails.append(candidate)
    found = EMAIL_RE.findall(soup.get_text())
    for e in found:
        if is_probable_email(e) and e not in panel_emails:
            panel_emails.append(e)

    return name, address, website, phone, panel_emails

# -------------------- OPTIMIZED SCROLL & COLLECT --------------------
def optimized_collect_links(driver, cfg=CFG) -> List[str]:
    """Improved link collection with better scroll detection and forced scrolling"""
    try:
        # Wait for initial feed to load
        WebDriverWait(driver, 15).until(
            lambda d: len(d.find_elements(By.CSS_SELECTOR, "a[href*='/maps/place/']")) > 0
        )
    except TimeoutException:
        if cfg["VERBOSE"]:
            print("[WARN] No place links found within timeout")
        return []

    seen = set()
    links = []
    no_new_links_count = 0
    scroll_attempts = 0
    consecutive_block_events = 0
    last_height = 0
    force_scroll_count = 0

    # Initial link collection
    try:
        elements = driver.find_elements(By.CSS_SELECTOR, "a[href*='/maps/place/']")
        for elem in elements:
            href = elem.get_attribute('href')
            if href and href not in seen:
                seen.add(href)
                links.append(href)
        if cfg["VERBOSE"]:
            print(f"[INFO] Initial collection: {len(links)} links found")
    except Exception as e:
        if cfg["VERBOSE"]:
            print(f"[WARN] Error during initial collection: {e}")

    # Use human-like actions if enabled
    if cfg.get("USE_HUMAN_ACTIONS", True):
        random_mouse_movement(driver)

    while scroll_attempts < cfg["MAX_SCROLLS"]:
        scroll_attempts += 1

        try:
            # Multiple scroll strategies
            scroll_successful = False

            # Strategy 1: Try feed scrolling first
            try:
                feed = driver.find_element(By.CSS_SELECTOR, "div[role='feed']")
                if feed:
                    driver.execute_script("arguments[0].scrollBy(0, arguments[1]);", feed, cfg["SCROLL_CHUNK"])
                    scroll_successful = True
                    if cfg["VERBOSE"]:
                        print(f"[DEBUG] Feed scroll successful")
            except (NoSuchElementException, WebDriverException):
                pass

            # Strategy 2: Window scrolling as fallback
            if not scroll_successful:
                try:
                    driver.execute_script("window.scrollBy(0, arguments[0]);", cfg["SCROLL_CHUNK"])
                    scroll_successful = True
                    if cfg["VERBOSE"]:
                        print(f"[DEBUG] Window scroll successful")
                except WebDriverException:
                    pass

            # Strategy 3: Page end scrolling as last resort
            if not scroll_successful:
                try:
                    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                    scroll_successful = True
                    if cfg["VERBOSE"]:
                        print(f"[DEBUG] End scroll successful")
                except WebDriverException:
                    pass

            # Wait for content to load
            pause = random.uniform(cfg["SCROLL_PAUSE_MIN"], cfg["SCROLL_PAUSE_MAX"])
            time.sleep(pause)

            # Check for page height changes (indicator of new content loading)
            try:
                current_height = driver.execute_script("return document.body.scrollHeight")
                if current_height > last_height:
                    last_height = current_height
                    if cfg["VERBOSE"]:
                        print(f"[DEBUG] Page height increased to {current_height}")
            except WebDriverException:
                pass

            # Collect links after scroll
            elements = driver.find_elements(By.CSS_SELECTOR, "a[href*='/maps/place/']")
            new_links_this_round = 0

            for elem in elements:
                try:
                    href = elem.get_attribute('href')
                    if href and href not in seen:
                        seen.add(href)
                        links.append(href)
                        new_links_this_round += 1

                        # Occasionally simulate mouse movement near new links
                        if cfg.get("USE_HUMAN_ACTIONS", True) and random.random() < 0.1:
                            try:
                                ActionChains(driver).move_to_element(elem).perform()
                            except Exception:
                                pass

                except StaleElementReferenceException:
                    continue

            # Advanced block detection
            if advanced_captcha_detection(driver):
                consecutive_block_events += 1
                print(f"[WARN] Advanced CAPTCHA/block detected (event {consecutive_block_events})")

                if consecutive_block_events >= cfg["MAX_CONSECUTIVE_BLOCKS"]:
                    print("[ERROR] Multiple block events detected. Stopping collection.")
                    break

                if handle_captcha_situation(driver, cfg):
                    consecutive_block_events = 0
                else:
                    continue

            # Improved stopping logic
            min_results = cfg.get("MIN_RESULTS_BEFORE_STOP", 15)

            if new_links_this_round == 0:
                no_new_links_count += 1

                # Only consider stopping if we have enough results
                if len(links) >= min_results:
                    if no_new_links_count >= cfg["NO_NEW_BREAK_CYCLES"]:
                        if cfg["VERBOSE"]:
                            print(f"[INFO] No new links for {no_new_links_count} attempts and have {len(links)} results - stopping")
                        break
                else:
                    # Force more scrolling if we don't have enough results yet
                    if cfg.get("FORCE_SCROLLING", True) and no_new_links_count < 10:
                        force_scroll_count += 1
                        if cfg["VERBOSE"]:
                            print(f"[INFO] Force scrolling (attempt {force_scroll_count}) - only {len(links)} links found")
                        # Don't break, continue scrolling
                        no_new_links_count = min(no_new_links_count, 3)  # Reset counter partially
            else:
                no_new_links_count = 0
                force_scroll_count = 0

            if cfg["VERBOSE"]:
                print(f"[INFO] Scroll {scroll_attempts}: {len(links)} total links ({new_links_this_round} new)")

            # Additional smart scrolling for better content loading
            if cfg.get("SMART_SCROLLING", True):
                if new_links_this_round > 0:
                    human_like_scroll(driver, scroll_direction="down")
                    natural_random_pause(0.8, 1.2)
                elif len(links) < min_results:
                    # More aggressive scrolling when we need more results
                    human_like_scroll(driver, scroll_direction="down")
                    natural_random_pause(1.0, 1.5)

            # Add occasional random pause
            if random.random() < 0.05:  # 5% chance
                natural_random_pause(1.5, 2.5)

        except Exception as e:
            if cfg["VERBOSE"]:
                print(f"[WARN] Error during link collection: {e}")
            # Don't break immediately, try to continue
            continue

    if cfg["VERBOSE"]:
        print(f"[INFO] Collection complete: {len(links)} unique links found in {scroll_attempts} scrolls")
        if force_scroll_count > 0:
            print(f"[INFO] Used forced scrolling {force_scroll_count} times")

    return links

# -------------------- LEGACY COMPATIBILITY --------------------
def collect_feed_links(driver, cfg=CFG) -> List[str]:
    """Legacy function for backward compatibility"""
    return optimized_collect_links(driver, cfg)

# -------------------- ADVANCED MAIN ORCHESTRATION --------------------
def run_single_session_scrape(driver, query: str, cfg=CFG, existing_rows=None) -> List[Dict]:
    """Run a single scraping session with enhanced features"""
    if existing_rows is None:
        existing_rows = []

    monitor = PerformanceMonitor()
    rows = []
    seen_names = set(row['name'] for row in existing_rows)

    try:
        # Use optimized link collection
        start_time = time.time()
        links = optimized_collect_links(driver, cfg)
        monitor.record_timing('link_collection', time.time() - start_time)
        monitor.record_count('links_found', len(links))

        if not links:
            print("[ERROR] No candidate links found — aborting.")
            return rows

        cap = min(cfg["MAX_VISIT_PAGES"], len(links))
        if cfg["MAX_PLACES_LIMIT"] and cfg["MAX_PLACES_LIMIT"] > 0:
            cap = min(cap, cfg["MAX_PLACES_LIMIT"])
        if cfg["VERBOSE"]:
            print(f"[INFO] Will visit up to {cap} detail pages (of {len(links)} candidates)")

        visited = 0
        for i, link in enumerate(links[:cap], start=1):
            if cfg["VERBOSE"]:
                print(f"[INFO] Visiting {i}/{cap}: {link}")

            try:
                # Add human-like behavior before navigation
                if cfg.get("USE_HUMAN_ACTIONS", True):
                    random_mouse_movement(driver)
                    natural_random_pause(0.5, 1.0)

                driver.get(link)
                time.sleep(random.uniform(cfg["CLICK_SLEEP_MIN"], cfg["CLICK_SLEEP_MAX"]))

                # Enhanced CAPTCHA detection
                if advanced_captcha_detection(driver):
                    print("[WARN] Advanced CAPTCHA/block detected on detail page.")
                    if handle_captcha_situation(driver, cfg):
                        # If block was handled, continue with this page
                        time.sleep(random.uniform(2, 3))
                    else:
                        print("[INFO] Skipping to next page due to persistent block")
                        continue

                # Create BeautifulSoup with fallback parser
                try:
                    soup = BeautifulSoup(driver.page_source, "lxml")
                except Exception as e:
                    if CFG["VERBOSE"]:
                        print(f"[WARN] lxml parser failed, falling back to html.parser: {e}")
                    try:
                        soup = BeautifulSoup(driver.page_source, "html.parser")
                    except Exception as e2:
                        print(f"[ERROR] All parsers failed: {e2}")
                        continue

                name, address, website, phone, panel_emails = extract_details_from_soup(soup)

                # Clean website URLs
                if website and "www.google.com/url?" in website:
                    q = re.search(r'[?&]q=(http[^&]+)', website)
                    if q: website = q.group(1)

                # Process emails with enhanced validation
                emails = list(dict.fromkeys([e for e in panel_emails if is_probable_email(e)]))
                if not emails and website:
                    site_emails = fetch_emails_from_website(website, cfg)
                    if site_emails:
                        emails.extend(site_emails)
                        emails = list(dict.fromkeys(emails))  # Remove duplicates

                # Skip duplicates and empty entries
                if not name or name in seen_names:
                    if cfg["VERBOSE"]:
                        print(f"[INFO] Skipping duplicate or empty entry: '{name}'")
                    continue

                seen_names.add(name)
                row_data = {
                    "name": name,
                    "address": address,
                    "website": website,
                    "phone": phone,
                    "emails": ";".join(emails),
                    "google_link": link
                }
                rows.append(row_data)
                monitor.increment('items_collected')
                visited += 1

                # Adaptive timing based on success rate
                if cfg.get("ADAPTIVE_TIMING", True):
                    success_rate = visited / i if i > 0 else 1
                    if success_rate > 0.8:  # High success rate - we can be more aggressive
                        pause = random.uniform(cfg["INTER_ITEM_SLEEP_MIN"] * 0.7,
                                             cfg["INTER_ITEM_SLEEP_MAX"] * 0.8)
                    else:  # Lower success rate - be more cautious
                        pause = random.uniform(cfg["INTER_ITEM_SLEEP_MIN"] * 1.2,
                                             cfg["INTER_ITEM_SLEEP_MAX"] * 1.3)
                else:
                    pause = random.uniform(cfg["INTER_ITEM_SLEEP_MIN"], cfg["INTER_ITEM_SLEEP_MAX"])

                if cfg["VERBOSE"]:
                    print(f"[INFO] Collected [{visited}] {name} — sleeping {pause:.2f}s")
                time.sleep(pause)

            except Exception as e:
                print(f"[ERROR] An error occurred while processing {link}: {e}")
                continue

    except Exception as e:
        print("[ERROR] Fatal error during scraping session:", e)

    finally:
        monitor.print_summary()

    return rows

def resilient_scrape_with_retry(query: str, cfg=CFG, max_attempts: int = None) -> List[Dict]:
    """Main scraping function with retry logic and progress tracking"""
    if max_attempts is None:
        max_attempts = cfg.get("MAX_RETRIES", 3)

    attempt = 0
    all_results = []

    while attempt < max_attempts:
        attempt += 1
        print(f"\n{'='*50}")
        print(f"[INFO] Scraping attempt {attempt}/{max_attempts}")
        print(f"{'='*50}")

        driver = None
        try:
            # Create enhanced driver
            driver = make_chrome_driver(cfg)
            if not driver:
                print("[ERROR] Could not start the browser. Aborting.")
                continue

            # Load previous session if available
            if cfg.get("SAVE_COOKIES", True):
                cookie_file = cfg.get("COOKIE_FILE", "maps_session.pkl")
                if os.path.exists(cookie_file):
                    if load_session_data(driver, cookie_file):
                        print("[INFO] Previous session loaded successfully")

            # Navigate to search
            search_url = f"https://www.google.com/maps/search/{quote(query)}"
            if cfg["VERBOSE"]:
                print("[INFO] Opening search URL:", search_url)

            driver.get(search_url)
            time.sleep(random.uniform(2.0, 4.0))  # Reduced initial wait

            # Run single session
            results = run_single_session_scrape(driver, query, cfg, all_results)

            if results:
                all_results.extend(results)

                # Save checkpoint
                checkpoint_file = f"checkpoint_{sanitize_filename(query)}"
                write_csv(all_results, checkpoint_file, cfg)

                # Save session data
                if cfg.get("SAVE_COOKIES", True):
                    save_session_data(driver, cfg.get("COOKIE_FILE", "maps_session.pkl"))

                print(f"[SUCCESS] Session {attempt} completed with {len(results)} new results")
                return all_results
            else:
                print(f"[WARN] No results collected in attempt {attempt}")

        except Exception as e:
            print(f"[ERROR] Attempt {attempt} failed: {e}")
            import traceback
            if cfg["VERBOSE"]:
                traceback.print_exc()

        finally:
            if driver:
                try:
                    driver.quit()
                except Exception:
                    pass

        # Exponential backoff between attempts
        if attempt < max_attempts:
            base_delay = cfg.get("RETRY_DELAY_BASE", 30)
            backoff_time = min(300, base_delay * (2 ** (attempt - 1)))  # Max 5 minutes
            print(f"[INFO] Waiting {backoff_time}s before retry...")
            time.sleep(backoff_time)

    print(f"[WARNING] All {max_attempts} attempts completed. Total results: {len(all_results)}")
    return all_results

# -------------------- LEGACY COMPATIBILITY --------------------
def run_scrape(query: str, cfg=CFG):
    """Legacy function for backward compatibility"""
    driver = None
    try:
        driver = make_chrome_driver(cfg)
        if not driver:
            print("[ERROR] Could not start the browser. Aborting.")
            return []

        # Load session if available
        if cfg.get("SAVE_COOKIES", True):
            cookie_file = cfg.get("COOKIE_FILE", "maps_session.pkl")
            if os.path.exists(cookie_file):
                load_session_data(driver, cookie_file)

        search_url = f"https://www.google.com/maps/search/{quote(query)}"
        if cfg["VERBOSE"]:
            print("[INFO] Opening search URL:", search_url)
        driver.get(search_url)
        time.sleep(random.uniform(4.0, 6.0))

        results = run_single_session_scrape(driver, query, cfg)

        # Save session
        if cfg.get("SAVE_COOKIES", True):
            save_session_data(driver, cfg.get("COOKIE_FILE", "maps_session.pkl"))

        return results

    except Exception as e:
        print("[ERROR] Fatal error during scraping:", e)
        return []
    finally:
        if driver:
            try:
                input("Scrape finished or stopped. Press Enter to close the browser and exit...")
            except Exception:
                pass
            try:
                driver.quit()
            except Exception:
                pass

# -------------------- CSV WRITING --------------------
def write_csv(rows: List[Dict], filename: str, cfg=CFG):
    if not rows:
        print("[INFO] No rows to write.")
        return
    fields = ["name", "address", "website", "phone", "emails", "google_link"]
    try:
        with open(filename, "w", newline="", encoding=cfg["CSV_ENCODING"]) as f:
            w = csv.DictWriter(f, fieldnames=fields)
            w.writeheader()
            for r in rows:
                out = {k: (r.get(k, "") or "") for k in fields}
                for k in ["name", "address", "website", "phone", "emails"]:
                    out[k] = clean_text(out[k])
                w.writerow(out)
        print(f"[INFO] Wrote {len(rows)} rows to '{filename}'")
    except Exception as e:
        print("[ERROR] Failed to write CSV:", e)

# -------------------- ENHANCED CLI ENTRY --------------------
def print_config_summary(cfg=CFG):
    """Print a concise summary of the current configuration"""
    print(f"\n{'='*50}")
    print("ENHANCED GOOGLE MAPS SCRAPER - CONFIGURATION")
    print(f"{'='*50}")
    print(f"Performance Mode: {cfg.get('PERFORMANCE_MODE', 'balanced')}")
    print(f"Human Actions: {'Enabled' if cfg.get('USE_HUMAN_ACTIONS', True) else 'Disabled'}")
    print(f"Smart Scrolling: {'Enabled' if cfg.get('SMART_SCROLLING', True) else 'Disabled'}")
    print(f"Adaptive Timing: {'Enabled' if cfg.get('ADAPTIVE_TIMING', True) else 'Disabled'}")
    print(f"Session Persistence: {'Enabled' if cfg.get('SAVE_COOKIES', True) else 'Disabled'}")
    print(f"Max Visits: {cfg['MAX_VISIT_PAGES']}")
    print(f"Max Retries: {cfg.get('MAX_RETRIES', 3)}")
    print(f"User-Agent: {cfg['USER_AGENT'][:50]}...")
    print(f"{'='*50}")

def main():
    if CFG["VERBOSE"]:
        print_config_summary(CFG)

    # Enhanced query input with validation
    while True:
        query = input("Enter Google Maps search query (e.g. 'restaurants in new york'): ").strip()
        if not query:
            print("No query provided. Please enter a search term.")
            continue

        # Basic query validation
        if len(query) < 2:
            print("Query too short. Please enter at least 2 characters.")
            continue

        break

    print(f"\n[INFO] Starting enhanced scrape for: {query}")
    print("[INFO] This may take several minutes depending on the number of results...")

    # Choose scraping mode
    print("\nSelect scraping mode:")
    print("1. Resilient (recommended) - Automatic retries and recovery")
    print("2. Standard - Single attempt with basic error handling")
    print("3. Legacy - Original behavior")

    mode_choice = input("Enter mode [1-3, default=1]: ").strip() or "1"

    start_time = time.time()
    rows = []

    try:
        if mode_choice == "1":
            print("[INFO] Using resilient scraping mode with automatic retries...")
            rows = resilient_scrape_with_retry(query, CFG)
        elif mode_choice == "2":
            print("[INFO] Using standard scraping mode...")
            rows = run_scrape(query, CFG)
        elif mode_choice == "3":
            print("[INFO] Using legacy scraping mode...")
            # Call original logic through legacy function
            rows = run_scrape(query, CFG)
        else:
            print("[WARN] Invalid choice. Using resilient mode...")
            rows = resilient_scrape_with_retry(query, CFG)

        # Performance summary
        total_time = time.time() - start_time
        print(f"\n{'='*50}")
        print("SCRAPING COMPLETE - PERFORMANCE SUMMARY")
        print(f"{'='*50}")
        print(f"Total Results: {len(rows)}")
        print(f"Total Time: {total_time:.2f} seconds")
        if len(rows) > 0:
            print(f"Average Time per Result: {total_time/len(rows):.2f} seconds")
            print(f"Results per Minute: {len(rows)/(total_time/60):.1f}")

        # Save final results
        if rows:
            filename = sanitize_filename(query)
            write_csv(rows, filename, CFG)

            # Also save a detailed report
            report_filename = filename.replace('.csv', '_report.txt')
            with open(report_filename, 'w', encoding='utf-8') as f:
                f.write(f"Google Maps Scraping Report\n")
                f.write(f"Query: {query}\n")
                f.write(f"Date: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}\n")
                f.write(f"Total Results: {len(rows)}\n")
                f.write(f"Total Time: {total_time:.2f} seconds\n")
                f.write(f"\nConfiguration:\n")
                for k, v in CFG.items():
                    if k != 'USER_AGENT':  # Skip long user-agent
                        f.write(f"  {k}: {v}\n")
                f.write(f"\nSample Results:\n")
                for i, row in enumerate(rows[:5]):  # First 5 results as sample
                    f.write(f"{i+1}. {row.get('name', 'N/A')}\n")
                    f.write(f"   Address: {row.get('address', 'N/A')}\n")
                    f.write(f"   Phone: {row.get('phone', 'N/A')}\n")
                    f.write(f"   Emails: {row.get('emails', 'N/A')}\n\n")

            print(f"[INFO] Detailed report saved to: {report_filename}")

        print(f"\n[SUCCESS] Done. Collected {len(rows)} rows.")

    except KeyboardInterrupt:
        print("\n[INFO] Scraping interrupted by user.")
        if rows:
            filename = f"interrupted_{sanitize_filename(query)}"
            write_csv(rows, filename, CFG)
            print(f"[INFO] Partial results saved to: {filename}")
    except Exception as e:
        print(f"\n[ERROR] An unexpected error occurred: {e}")
        import traceback
        if CFG["VERBOSE"]:
            traceback.print_exc()

        # Try to save any partial results
        if rows:
            filename = f"error_{sanitize_filename(query)}"
            write_csv(rows, filename, CFG)
            print(f"[INFO] Partial results saved to: {filename}")

if __name__ == "__main__":
    try:
        if not check_dependencies():
            sys.exit(1)
        main()
    except Exception as e:
        print("\n[CRITICAL ERROR] An unexpected error occurred. See details below:")
        import traceback
        traceback.print_exc()
    finally:
        print("\nScript execution has finished.")
        try:
            input("Press Enter to exit...")
        except Exception:
            pass